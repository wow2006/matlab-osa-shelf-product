clear all;clc;
%% read matching data from file
fid = fopen('matchings.txt');

%read number of matches
matches = cell2mat(textscan(fid, '%d',1));
% read numeric data
C_data = textscan(fid, '%d %d %d %d',1);
for k = 1 : matches - 1
    C_data = [C_data;textscan(fid, '%d %d %d %d',1)];
end

C_data = cell2mat(C_data);

fclose(fid);

%% create contoured data from product views
%clear all;clc;close all;
product = imread('mySp30pC.jpg');
%figure(1), imshow(product), title('product');


bw = im2bw(product,0.9);
%figure(2), imshow(bw), title('product bw');

se = strel('rectangle', [5 5]);
I_closed = imclose(bw,se);
se = strel('rectangle', [15 15]);
I_opened = imopen(I_closed,se);
I_opened = ~I_opened;
BWdfill = imfill(I_opened, 'holes');
%figure(3), imshow(BWdfill), title('product after morphological close/open');

productViewsLabled = bwlabel(BWdfill,4);


s = regionprops(BWdfill, 'Centroid');
colorSpace = char('blue','green','red','cyan','magenta','yellow','black');
figure(4), imshow(product), title('product with Centroid Locations');
hold on
numObj = numel(s);
%indexing the product views
for k = 1 : numObj
    %plot(s(k).Centroid(1), s(k).Centroid(2), 'b*');
    text(s(k).Centroid(1),s(k).Centroid(2),sprintf('%d', k),'FontSize', 25 ,'FontWeight','bold','BackgroundColor',[.7 .9 .7],'Color', colorSpace(k,:));
end

%painting the matched ASIFT cordinates
for k = 1 : matches
    if (productViewsLabled(C_data(k,4), C_data(k,3)) > 0)
        plot(C_data(k,3), C_data(k,4), strcat(colorSpace(productViewsLabled(C_data(k,4), C_data(k,3)),:),'*')); 
    end
end
hold off
 

%% shelf compare

shelf = imread('myS.jpg');
figure(5), imshow(shelf), title('shelf with matched ASIFT cordinates');
hold on
%painting the matched ASIFT cordinates
for k = 1 : matches
    if (productViewsLabled(C_data(k,4), C_data(k,3)) > 0)
        plot(C_data(k,1), C_data(k,2), strcat(colorSpace(productViewsLabled(C_data(k,4), C_data(k,3)),:),'*'),'MarkerSize',20);
    end
end
hold off

%% ncc
%[xmin ymin width height]
rect_shelf = [910-5 173-5 10 10];
rect_prod = [299-5 133-5 10 10];

%rect_shelf = [1459-5 252-5 10 10];
%rect_prod = [334-5 867-5 10 10];

sub_shelf = imcrop(shelf,rect_shelf);
sub_prod = imcrop(product,rect_prod);

subplot(2, 2, 1)
imshow(sub_shelf), title('shelf cropped');
subplot(2, 2, 2)
imshow(sub_prod), title('product cropped');

rS = sub_shelf(:,:,1);
gS = sub_shelf(:,:,2);
bS = sub_shelf(:,:,3);

rP = sub_prod(:,:,1);
gP = sub_prod(:,:,2);
bP = sub_prod(:,:,3);
subplot(2, 2, 3)
plot3(rS(:),gS(:),bS(:),'.')
grid('on')
xlabel('Red (Band 3)')
ylabel('Green (Band 2)')
zlabel('Blue (Band 1)')
title('Scatterplot of Shelf')

subplot(2, 2, 4)
plot3(rP(:),gP(:),bP(:),'.')
grid('on')
xlabel('Red (Band 3)')
ylabel('Green (Band 2)')
zlabel('Blue (Band 1)')
title('Scatterplot of Product')

%c = normxcorr2(sub_shelf,sub_prod);
%figure, surf(c), shading flat

%% k-means
opts = statset('Display','final');
[idx,ctrs] = kmeans(double([C_data(:,3) C_data(:,4)]),numObj,'Distance','cityblock','Replicates',15,'Options',opts);

for k = 1 : numObj
    plot(ctrs(k,1),ctrs(k,2), 'y*' ,'MarkerSize',12);
    %%text(idx(k,1),idx(k,2),sprintf('%d', k),'FontSize', 25 ,'FontWeight','bold','BackgroundColor',[.7 .9 .7],'Color', colorSpace(mod(k,numObj)+1,:));
end

%% CIELAB

product = imread('mySp30pC.jpg');
figure(1), imshow(product), title('product');

load regioncoordinates;

nColors = 6;
sample_regions = false([size(product,1) size(product,2) nColors]);

for count = 1:nColors
  sample_regions(:,:,count) = roipoly(product,region_coordinates(:,1,count),...
                                      region_coordinates(:,2,count));
end

%imshow(sample_regions(:,:,2)),title('sample region for red');

cform = makecform('srgb2lab');
lab_product = applycform(product,cform);

a = lab_product(:,:,2);
b = lab_product(:,:,3);
color_markers = zeros([nColors, 2]);

for count = 1:nColors
  color_markers(count,1) = mean2(a(sample_regions(:,:,count)));
  color_markers(count,2) = mean2(b(sample_regions(:,:,count)));
end



% 0 = background, 1 = red, 2 = green, 3 = purple, 4 = magenta, and 5 = yellow.

color_labels = 0:nColors-1;

%Initialize matrices to be used in the nearest neighbor classification.
a = double(a);
b = double(b);
distance = zeros([size(a), nColors]);

%Perform classification
for count = 1:nColors
  distance(:,:,count) = ( (a - color_markers(count,1)).^2 + ...
                      (b - color_markers(count,2)).^2 ).^0.5;
end

[value, label] = min(distance,[],3);
label = color_labels(label);
clear value distance;

%Display Results of Nearest Neighbor Classification
rgb_label = repmat(label,[1 1 3]);
segmented_images = repmat(uint8(0),[size(product), nColors]);

for count = 1:nColors
  color = product;
  color(rgb_label ~= color_labels(count)) = 0;
  segmented_images(:,:,:,count) = color;
end

imshow(segmented_images(:,:,:,1)), title('red objects');

